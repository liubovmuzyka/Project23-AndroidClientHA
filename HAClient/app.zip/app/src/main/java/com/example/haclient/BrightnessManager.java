package com.example.haclient;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.Settings;

public class BrightnessManager {

    final MainActivity activity;
    private Context context;

    private int brightness;

    public BrightnessManager(MainActivity activity, Context context) {
        this.activity = activity;
        this.context = context;
        try{
            Settings.System.putInt(context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);

            brightness = Settings.System.getInt(context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
        }
        catch(Settings.SettingNotFoundException e){
            System.out.println("Cannot access system brightness");
            e.printStackTrace();
        }
    }

    public int getBrightness() {
        return brightness;
    }


    public int updateBrightness()  {
        brightness = brightness/2;
        Settings.System.putInt(context.getContentResolver(),  Settings.System.SCREEN_BRIGHTNESS, brightness);
        return getBrightness();
    }

}
