package com.example.haclient;

import static android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import android.Manifest;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Intent;
import android.os.PowerManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONException;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private LocationManager locationManager;
    MyLocationListener mylistener;
    TextView txtLat, txtLng;
    Location location;

    boolean music_on = false;
    String state;
    MusicManager musicManager;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!foregroundServiceRunning()) {
            Intent serviceIntent = new Intent(this, MyService.class);
            startForegroundService(serviceIntent);
        }

        txtLat = (TextView) findViewById(R.id.latitude);
        txtLng = (TextView) findViewById(R.id.longtitude);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (!NotificationManagerCompat.getEnabledListenerPackages(this).contains(getPackageName())) {        //ask for permission
                Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                startActivity(intent);
            }
        }
        boolean settingsCanWrite = Settings.System.canWrite(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent();
            String packageName = getPackageName();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                if (!settingsCanWrite) {
                    intent.setAction(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                }
                intent.setData(Uri.parse("package:" + packageName));
                startActivity(intent);
            }
        }


        Intent mServiceIntent = new Intent(this, NotificationsManager2.class);
        startService(mServiceIntent);

        setContentView(R.layout.activity_main);

        /*mediaPlayer = MediaPlayer.create(this, R.raw.alarm);
        //mediaPlayer.start();
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

            @Override
            public void onCompletion(MediaPlayer mPlayer) {
                mPlayer.release();

            }
        });*/

        mylistener = new MyLocationListener(MainActivity.this, this);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10, 0, mylistener);

        location = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);

        musicManager = new MusicManager(MainActivity.this, this);

        try {
            state = musicManager.getStateMusic();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        timerOn_Alarm();

        timerOn_Battery();

        BrightnessManager brightnessManager = new BrightnessManager(MainActivity.this, this);

        System.out.println("old Brightness: " + brightnessManager.getBrightness() + " and new Brightness: " + brightnessManager.updateBrightness());

        SensorsManager sensorsManager = new SensorsManager(MainActivity.this, this);


        startService(new Intent(this, NotificationsManager2.class));
        startActivity(new Intent(ACTION_NOTIFICATION_LISTENER_SETTINGS));


        Button button = (Button) findViewById(R.id.locationbutton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // System.out.println("MYLISTNER: "+mylistener.getLatitude());
                Log.d("BUTTONS", "User tapped the LocationButton");
                txtLat = (TextView) findViewById(R.id.latitude);
                txtLng = (TextView) findViewById(R.id.longtitude);
                txtLat.setText(mylistener.getLatitude());
                txtLng.setText(mylistener.getLongtitude());

            }
        });

    }

    public boolean foregroundServiceRunning() {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if (MyService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void timerOn_Alarm() {
        Timer timer = new Timer();
        TimerTask task = new MusicManager(MainActivity.this, this);
        timer.schedule(task, 0, 2000);
    }

    public void timerOn_Battery() {
        Timer timer = new Timer();
        TimerTask task = new BatteryState(MainActivity.this, this);
        timer.schedule(task, 0, 5000);
    }

    //    public double getLatitude() {
//        return latitude;
//    }
//
//    public double getLongtitude() {
//        return longtitude;
//    }
//
//    double latitude, longtitude;

//    class MusicManager extends TimerTask {
//        final MainActivity activity;
//
//        public MusicManager(MainActivity activity) {
//            this.activity = activity;
//        }
//
//        public void run() {
//            try {
//                state = getStateMusic();
//                if (state.contains("on")) {
//                    cancel();
//                    activity.runOnUiThread(new Runnable() {
//                        public void run() {
//                            startAlertDialog();
//                        }
//                    });
//                }
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            } catch (JSONException e) {
//                throw new RuntimeException(e);
//            }
//        }
//    }


//    public void startAlertDialog() {
//        mediaPlayer.setLooping(true);
//        mediaPlayer.start();
//
//        // Create the object of AlertDialog Builder class
//        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//        builder.setMessage("Motion is detected! ");
//        builder.setTitle("Alert !");
//        // Set Cancelable false for when the user clicks on the outside the Dialog Box then it will remain show
//        builder.setCancelable(false);
//
//        builder.setNeutralButton("OK", (DialogInterface.OnClickListener) (dialog, which) -> {
//            // When the user click yes button then app will close
//            mediaPlayer.pause();
//            try {
//                setStatusMusic();
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            } catch (JSONException e) {
//                throw new RuntimeException(e);
//            }
//            dialog.cancel();
//            //timerOn();
//        });
//
//        AlertDialog alertDialog = builder.create();
//        alertDialog.show();
//    }

//    private void setMyLastLocation() {
//        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            return;
//        }
//        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
//            @Override
//            public void onSuccess(Location location) {
//                if (location != null) {
//                    double lat = location.getLatitude();
//                    double longi = location.getLongitude();
//                    LatLng latLng = new LatLng(lat, longi);
//                    Log.d("location", "MyLastLocation coordinat :" + latLng);
//                }
//            }
//        });
//    }
//
//    private static final String url = "http://rp3:8080/updateGPS?";
//
//
//    private String sendGPStoServer() throws IOException, JSONException {
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//
//        StrictMode.setThreadPolicy(policy);
//
//
//        URL obj = new URL(url + "latitude=" + getLatitude() + "&" + "longtitude=" + getLongtitude());
//        System.out.println(url + "latitude=" + getLatitude() + "&" + "longtitude=" + getLongtitude());
//        HttpURLConnection httpURLConnection = (HttpURLConnection) obj.openConnection();
//        httpURLConnection.setRequestMethod("GET");
//        httpURLConnection.setRequestProperty("content-type", "application/json");
//
//        String inline = "";
//        Scanner scanner = new Scanner(httpURLConnection.getInputStream());
//
//        while (scanner.hasNext()) {
//            inline += scanner.nextLine();
//        }
//        scanner.close();
//        return inline;
//
//    }

    //    private static final String url_music_state = "http://rp3:8088/getStatusMusic";
//    private static final String url_music_off = "http://rp3:8088/updateStatusMusic?stateMusic=off";
//
//    private String setStatusMusic() throws IOException, JSONException {
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//
//        StrictMode.setThreadPolicy(policy);
//
//        URL obj = new URL(url_music_off);
//        HttpURLConnection httpURLConnection = (HttpURLConnection) obj.openConnection();
//        httpURLConnection.setRequestMethod("GET");
//        httpURLConnection.setRequestProperty("content-type", "application/json");
//
//        String inline = "";
//        Scanner scanner = new Scanner(httpURLConnection.getInputStream());
//
//        while (scanner.hasNext()) {
//            inline += scanner.nextLine();
//        }
//        scanner.close();
//        System.out.println(inline);
//        return inline;
//
//    }
//
//    private String getStateMusic() throws IOException, JSONException {
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//
//        StrictMode.setThreadPolicy(policy);
//
//        URL obj = new URL(url_music_state);
//        HttpURLConnection httpURLConnection = (HttpURLConnection) obj.openConnection();
//        httpURLConnection.setRequestMethod("GET");
//        httpURLConnection.setRequestProperty("content-type", "application/json");
//
//        String inline = "";
//        Scanner scanner = new Scanner(httpURLConnection.getInputStream());
//
//        while (scanner.hasNext()) {
//            inline += scanner.nextLine();
//        }
//        scanner.close();
//        System.out.println(inline);
//        return inline;
//
//    }
//

}
